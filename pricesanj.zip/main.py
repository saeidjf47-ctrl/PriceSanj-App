from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
import csv
import requests
import os

DATA_FILE = "pricesanj_data.csv"

def get_usd_rate():
    try:
        r = requests.get("https://api.exchangerate.host/latest?base=IRR&symbols=USD", timeout=5)
        return 1 / r.json()["rates"]["USD"]
    except:
        return 42000

class PriceChecker(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", **kwargs)
        self.data = self.load_data()

        self.add_widget(Label(text="کد کالا", font_size=18))
        self.code_input = TextInput(multiline=False, size_hint_y=None, height=45)
        self.add_widget(self.code_input)

        btn = Button(text="نمایش قیمت", size_hint_y=None, height=50)
        btn.bind(on_press=self.show_price)
        self.add_widget(btn)

        self.scroll = ScrollView()
        self.result = GridLayout(cols=1, size_hint_y=None)
        self.result.bind(minimum_height=self.result.setter("height"))
        self.scroll.add_widget(self.result)
        self.add_widget(self.scroll)

        self.profit_percent = 20

    def load_data(self):
        if not os.path.exists(DATA_FILE):
            return []
        with open(DATA_FILE, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def show_price(self, instance):
        self.result.clear_widgets()
        code = self.code_input.text.strip()

        item = next((x for x in self.data if x["کدکالا"] == code), None)
        if not item:
            self.result.add_widget(Label(text="کالا یافت نشد"))
            return

        usd = get_usd_rate()
        buy_price = int(item["قیمت خریدتومان"])
        cost = int(item["هزینه حمل"]) + int(item["سایرهزینه ها"])
        sell = buy_price + cost
        sell += sell * self.profit_percent / 100

        text = f"""نام کالا: {item['نام کالا']}
قیمت خرید: {buy_price:,} تومان
قیمت دلار خرید: {buy_price/usd:.2f}
قیمت فروش پیشنهادی: {int(sell):,} تومان
"""
        self.result.add_widget(Label(text=text, size_hint_y=None, height=200))

class PriceSanjApp(App):
    def build(self):
        return PriceChecker()

if __name__ == "__main__":
    PriceSanjApp().run()
